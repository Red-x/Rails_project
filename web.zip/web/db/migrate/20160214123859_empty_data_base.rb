class EmptyDataBase < ActiveRecord::Migration
  def change
  end
end
