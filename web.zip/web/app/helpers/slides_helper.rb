module SlidesHelper
end
