class Lecture < ActiveRecord::Base
	 

end
